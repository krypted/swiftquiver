//
//  Images.swift
//  PingAddDevice
//
//

import SwiftUI

extension Image {
    static let dropdown_icon = Image("dropdown_icon")
    static let printer = Image("printer_demo")
}
