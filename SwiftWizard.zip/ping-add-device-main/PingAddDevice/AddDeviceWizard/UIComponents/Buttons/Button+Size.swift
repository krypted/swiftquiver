//
//  Button+Size.swift
//  PingAddDevice
//
//

import SwiftUI

extension View {
    func buttonFrame() -> some View {
        frame(width: 185, height: 40)
    }
}
