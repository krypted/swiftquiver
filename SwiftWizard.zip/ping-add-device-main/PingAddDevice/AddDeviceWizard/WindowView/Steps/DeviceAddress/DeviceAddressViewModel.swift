//
//  DeviceAddressViewModel.swift
//  PingAddDevice
//
//

import Combine

final class DeviceAddressViewModel: ObservableObject {
    @Published var selected: String?
}
