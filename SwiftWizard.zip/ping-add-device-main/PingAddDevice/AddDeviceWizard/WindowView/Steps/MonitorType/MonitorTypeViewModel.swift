//
//  DeviceSelectionViewModel.swift
//  PingAddDevice
//
//

import Combine

final class MonitorTypeViewModel: ObservableObject {
    @Published var selected: String?
}

